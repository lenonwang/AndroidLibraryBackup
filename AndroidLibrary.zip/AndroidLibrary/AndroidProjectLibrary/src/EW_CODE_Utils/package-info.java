/**
 * Copyright@2014 
 * 
 * Author is wanglei.
 *
 * All right reserved
 *
 * Created on 2014 2014-5-26 上午11:58:06
 */
/**
 * @author wanglei
 */
package EW_CODE_Utils;