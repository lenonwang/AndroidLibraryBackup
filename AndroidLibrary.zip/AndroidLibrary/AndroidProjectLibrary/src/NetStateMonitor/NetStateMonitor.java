/**
 * Copyright@2014 
 * 
 * Author is wanglei.
 *
 * All right reserved
 *
 * Created on 2014 2014-5-26 上午11:00:39
 */
package NetStateMonitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

/**
 * TODO AUTOCheckNetState
 * 
 * @author wanglei
 */
public class NetStateMonitor {
	private static BroadcastReceiver connectionReceiver;

	public static void registerNetStateMonitor(Context context) {
		connectionReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				ConnectivityManager connectMgr = (ConnectivityManager) context
						.getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo mobNetInfo = connectMgr
						.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
				NetworkInfo wifiNetInfo = connectMgr
						.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
				if (!mobNetInfo.isConnected() && !wifiNetInfo.isConnected()) {
					Toast.makeText(context, "网络未连接", Toast.LENGTH_LONG).show();
					// unconnect network
				} else {
					// connect network
					Toast.makeText(context, "网络连接正常", Toast.LENGTH_LONG).show();
				}
			}
		};
		// register net monitor
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
		context.registerReceiver(connectionReceiver, intentFilter);
	}

	/**
	 * 
	 * TODO unregister BroadCast
	 * 
	 * @param context
	 */
	public static void unRegisterNetStateMonitor(Context context) {
		context.unregisterReceiver(connectionReceiver);
	}

	/**
	 * 
	 * @param context
	 * @return TODO manual check net state method
	 */
	public static boolean CheckNetState(final Activity context) {
		ConnectivityManager connectMgr = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo mobNetInfo = connectMgr
				.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		NetworkInfo wifiNetInfo = connectMgr
				.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (!mobNetInfo.isConnected() && !wifiNetInfo.isConnected()) {
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setNegativeButton("取消", null)
					.setPositiveButton("设置网络",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									context.startActivityForResult(
											new Intent(
													android.provider.Settings.ACTION_WIRELESS_SETTINGS),
											1);
								}
							}).setIcon(android.R.drawable.ic_dialog_alert)
					.setMessage("请开启GPRS或者WIFI网络连接").setTitle("没有可用的网络！")
					.show();
			return false;
		}
		return true;
	}
}