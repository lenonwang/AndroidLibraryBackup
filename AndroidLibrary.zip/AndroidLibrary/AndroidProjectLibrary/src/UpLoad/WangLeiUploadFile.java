/**
 * Copyright@2014 
 * 
 * Author is wanglei.
 *
 * All right reserved
 *
 * Created on 2014 2014-5-26 下午6:00:34
 */
package UpLoad;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class WangLeiUploadFile {

	// private static final String TAG = "uploadFile";
	private static final String CHARSET = "utf-8";

	/**
	 * 
	 * TODO upload file to remote server
	 * 
	 * @param key
	 *            file key
	 * @param file
	 *            file value
	 * @param RequestURL
	 * @param handler null or nonnull
	 * @return
	 */
	public static String uploadFile(String key, File file, String RequestURL,
			Handler handler) {
		String BOUNDARY = UUID.randomUUID().toString();
		String PREFIX = "--";
		String LINE_END = "\r\n";
		String CONTENT_TYPE = "multi	part/form-data";
		String result = "";
		String error_code = "";

		try {
			System.out.println("UpLoadFile--------------------签名图片上传地址："
					+ RequestURL);
			URL url = new URL(RequestURL);
			Log.e("Mail", "RequestURL = " + RequestURL);
			// LogHelper.eLog("uploadFile", "RequestURL = " + RequestURL);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setUseCaches(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.setRequestProperty("Charset", "UTF-8");
			conn.setRequestProperty("Content-Type", CONTENT_TYPE + ";boundary="
					+ BOUNDARY);

			if (file != null)

			{
				DataOutputStream dos = new DataOutputStream(
						conn.getOutputStream());
				// StringBuffer sb1 = new StringBuffer();
				// sb1.append("--");
				// sb1.append(BOUNDARY);
				// sb1.append("\r\n");
				// sb1.append("Content-Disposition:  form-data; name=\"code\"\r\n\r\n");
				// sb1.append(code);
				// sb1.append("\r\n");
				// dos.write(sb1.toString().getBytes());

				StringBuffer sb2 = new StringBuffer();
				sb2.append("--");
				sb2.append(BOUNDARY);
				sb2.append("\r\n");
				sb2.append("Content-Disposition: form-data; name=\"" + key
						+ "\"; filename=\"" + file.getName() + "\"" + LINE_END);
				sb2.append("Content-Type: application/octet-stream; charset="
						+ CHARSET + LINE_END);
				sb2.append(LINE_END);
				dos.write(sb2.toString().getBytes());

				FileInputStream bis = new FileInputStream(file);
				byte[] bytes = new byte[1024];
				int len = 0;
				int havedownlength = 0;
				while ((len = bis.read(bytes)) != -1) {
					havedownlength = havedownlength + len;
					dos.write(bytes, 0, len);
				}
				bis.close();
				dos.write(LINE_END.getBytes());
				byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END)
						.getBytes();
				dos.write(end_data);
				dos.flush();

				DataInputStream reader = new DataInputStream(
						conn.getInputStream());
				byte[] buffer = new byte[4096];
				int count = 0;
				StringBuffer josn = new StringBuffer();
				while ((count = reader.read(buffer)) > 0) {
					String r_msg = new String(buffer, 0, count);
					josn.append(r_msg);
				}
				reader.close();
				JSONObject jb = new JSONObject(josn.toString());
				result = jb.optString("result");
				error_code = jb.optString("error_code");
				conn.disconnect();

				System.out.println("UploadFile" + result);
				System.out.println("UploadFile" + error_code);

				if (handler != null) {
					Message msg = new Message();
					if ("success".equals(result)) {
						msg.what = 0;
					} else {
						if ("6".equals(error_code)) {
							msg.what = 6;
						} else if ("7".equals(error_code)) {
							msg.what = 7;
						}
					}
					handler.sendMessage(msg);
				}
			}
		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}

}
