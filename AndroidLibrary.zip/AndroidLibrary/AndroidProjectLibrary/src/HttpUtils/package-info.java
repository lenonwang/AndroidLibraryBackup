/**
 * Copyright@2014 
 * 
 * Author is wanglei.
 *
 * All right reserved
 *
 * Created on 2014 2014-5-26 上午11:57:05
 */
/**
 * @author wanglei
 */
package HttpUtils;