/**
 * Copyright@2014 
 * 
 * Author is wanglei.
 *
 * All right reserved
 *
 * Created on 2014 2014-5-26 下午12:19:36
 */
package HttpUtils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * @author wanglei
 */
public class WangLeiHttpUtls {
	/**
	 * TODO doGet Request doing code
	 * 
	 * @return
	 */
	public static String executeHttpGet(String urlString) {
		String result = null;
		URL url = null;
		HttpURLConnection connection = null;
		InputStreamReader in = null;
		try {
			url = new URL(urlString);
			connection = (HttpURLConnection) url.openConnection();
			connection.connect();
			in = new InputStreamReader(connection.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(in);
			StringBuffer strBuffer = new StringBuffer();
			String line = null;
			while ((line = bufferedReader.readLine()) != null) {
				strBuffer.append(line);
			}
			result = strBuffer.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	/**
	 * TODO dopost Request doing code
	 * 
	 * @return
	 */
	public static String executeHttpPost(String urlString,
			HashMap<String, String> params) {
		String result = null;
		URL url = null;
		HttpURLConnection connection = null;
		InputStreamReader in = null;
		try {
			url = new URL(urlString);
			connection = (HttpURLConnection) url.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(5000);
			connection.setUseCaches(false);
			connection.setInstanceFollowRedirects(false);
			connection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			connection.connect();
			DataOutputStream dop = new DataOutputStream(
					connection.getOutputStream());
			dop.writeBytes(parseParams(params));
			dop.flush();
			dop.close();

			in = new InputStreamReader(connection.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(in);
			StringBuffer strBuffer = new StringBuffer();
			String line = null;
			while ((line = bufferedReader.readLine()) != null) {
				strBuffer.append(line);
			}
			result = strBuffer.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	/**
	 * TODO parse params from map by the format 'key'='value'
	 */
	public static String parseParams(HashMap<String, String> params) {
		Set<String> keys = params.keySet();
		Iterator<String> iterator = keys.iterator();
		StringBuffer sb = null;
		String key = null;
		int size = params.size();
		if (size == 1) {
			sb = new StringBuffer();
			if (iterator.hasNext()) {
				key = iterator.next();
				sb.append(key + "=" + params.get(key));
			}
			return sb.toString();
		} else {
			sb = new StringBuffer();
			while (iterator.hasNext()) {
				key = iterator.next();
				sb.append(key + "=" + params.get(key) + "&");
			}
			return sb.substring(0, sb.length() - 1);
		}
	}
}
